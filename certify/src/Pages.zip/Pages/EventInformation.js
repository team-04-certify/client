import React from "react";

import { InformationCard } from "../Components";

export default function EventInformation() {
  return (
    <div>
      <InformationCard />
    </div>
  );
}
