export { default as LandingPage } from "./LandingPage";
export { default as Register } from "./Register";
export { default as Login } from "./Login";
export { default as Events } from "./Events";
export { default as CreateEvent } from "./CreateEvent";
export { default as UpdateEvent } from "./UpdateEvent";
export { default as EventInformation } from "./EventInformation";
