import axios from "axios";
const baseUrl = "http://localhost:3000";

const setLoading = (loading) => {
  return { type: "SET_LOADING", payload: loading };
};

const setError = (error) => {
  return { type: "SET_ERROR", payload: error };
};

const setOrganizer = (organizer) => {
  return { type: "SET_ORGANIZER", payload: organizer };
};

const setRegister = (organizer) => {
  return { type: "SET_REGISTER", payload: organizer };
};

const getRegister = (payload) => {
  return (dispatch) => {
    dispatch(setLoading(true));
    axios({
      method: "POST",
      url: `${baseUrl}/register`,
      data: payload,
    })
      .then((user) => {
        dispatch(setRegister(user));
        return true;
      })
      .catch((err) => {
        console.log({ err: err.response.data });
        dispatch(setError(err.response.data));
        return false;
      });
    dispatch(setLoading(false));
  };
};

export default {
  setLoading,
  setError,
  setOrganizer,
  setRegister,
  getRegister,
};
