import organizer from "./OrganizersAction";

export default {
  organizer,
};
