const initialState = {
  organizer: {},
  loading: false,
  error: null,
};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case "SET_LOADING":
      return {
        ...state,
        loading: action.payload,
      };
    case "SET_ERROR":
      return {
        ...state,
        error: action.payload,
      };
    case "SET_ORGANIZER":
      return {
        ...state,
        organizer: action.payload,
      };
    case "SET_REGISTER":
      return {
        ...state,
        register: action.payload,
      };
    case "SET_REGISTER":
      return {
        ...state,
        register: action.payload,
      };

    default:
      return state;
  }
}
